package WFC_lessons;

public class WFC_customer{

	private int CustomerID;
	private String Customer_name;
	private String Customer_status;
	private String Name_Lesson;
	private String Day_week;
	private String Set_time;

	public int getCustomerID() {
		return CustomerID;
	}

	public void setCustomerid(int CustomerID) {
		this.CustomerID = CustomerID;
	}

	public String getCustomerName() {
		return Customer_name;
	}

	public void setCustomerName(String Customer_name) {
		this.Customer_name = Customer_name;
	}

	public String getstatus() {
		return Customer_status;
	}

	public void setstatus(String Customer_status) {
		this.Customer_status = Customer_status;
	}

	

	public String getName_Lesson() {
		return Name_Lesson;
	}

	public void setName_Lesson(String Name_Lesson) {
		this.Name_Lesson = Name_Lesson;
	}

	public String getDay_week() {
		return Day_week;
	}

	public void setDay_week(String Day_week) {
		this.Day_week = Day_week;
	}

	public String getShift() {
		return Set_time;
	}

	public void setshift(String Set_time) {
		this.Set_time = Set_time;
	}

	public WFC_customer(int CustomerID, String Customer_name, String Customer_status, String Name_Lesson,String Day_week, String Set_time)
        {
		super();
		this.CustomerID = CustomerID;
		this.Customer_name = Customer_name;
		this.Customer_status = Customer_status;
		this.Name_Lesson = Name_Lesson;
		this.Day_week = Day_week;
		this.Set_time = Set_time;
	}

	@Override
	public String toString() {
		return "customers [CustomerID=" + CustomerID + ", Customer_name=" + Customer_name + ", Customer_status=" + Customer_status
				+ ", Name_Lesson=" + Name_Lesson + ", Day_week=" + Day_week
				+ ", Set_time=" + Set_time + "]";
	}

}
