package WFC_lessons;
public class WFC_timetable {

	public void displayTimeTable(String i) {

		int lesson_id[] = { 1, 2, 3, 4, 5, 6, 7, 8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48};
		String Lesson[] = {"Yoga", "ZUMBA", "Aquacise", "Yoga" ,"Aquacise","Yoga", "ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga", "ZUMBA", "Aquacise","Yoga", "ZUMBA", "Aquacise  ","Yoga", "ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA","Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Spin","Yoga","ZUMBA", "Spin,","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","Spin", "Aquacise","Spin","ZUMBA", "Aquacise","Yoga","ZUMBA", "Spin","Yoga","ZUMBA", "Spin","Yoga","ZUMBA", "Spin","Yoga","Spin","Aquacise","Yoga","ZUMBA", "Spin","Yoga","ZUMBA", "Spin","Yoga","Spin", "Spin","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga","ZUMBA", "Aquacise","Yoga"};
		int price[] = { 100, 200, 300, 100, 300, 100, 200, 300, 100, 200,300, 100, 200,300, 100, 200,300, 100, 200,300,100, 200,300, 100, 200,300, 100, 200,300, 100, 200,300, 100, 200,300, 100, 200,300, 100, 200,300, 100, 200,300, 100, 200,300, 100};
		String day[] = { "Saturday", "Sunday", "Saturday", "Sunday", "Saturday","Sunday","Saturday","Sunday","Saturday","Sunday","Saturday","Sunday","Saturday","Sunday","Saturday","Sunday","Saturday", "Sunday", "Saturday", "Sunday", "Saturday","Sunday","Saturday","Sunday","Saturday","Sunday","Saturday", "Sunday", "Saturday", "Sunday", "Saturday","Sunday","Saturday","Sunday","Saturday","Sunday","Saturday", "Sunday", "Saturday", "Sunday", "Saturday","Sunday","Saturday","Sunday","Saturday","Sunday","Saturday","Sunday"};
		String workDate[] = { "05-03-2023", "05-03-2023", "12-03-2023", "12-03-2023","19-03-2023", "19-03-2023", "19-03-2023", "26-03-2023","26-03-2023","02-04-2023","02-04-2023", "09-04-2023", "09-04-2023", "16-04-2023","16-04-2023", "23-04-2023", "23-04-2023", "30-04-2023","30-04-2023","07-05-2023","07-05-2023", "14-05-2023", "14-05-2023", "21-05-2023","21-05-2023", "28-05-2023", "28-05-2023", "11-06-2023","12-06-2023","13-06-2023","07-06-2023", "09-06-2023", "12-06-2023", "11-06-2023","07-06-2023", "09-06-2023", "12-06-2023", "11-06-2023","12-06-2023","13-06-2023","07-06-2023", "09-06-2023", "12-06-2023", "11-06-2023","07-06-2023", "09-06-2023", "12-06-2023", "11-06-2023"};
		String time_shift[] = {"Morning" , "Evening", "Afternoon" , "Morning","Evening" , "Afternoon", "Afternoon" , "Morning","Evening","Afternoon","Morning" , "Evening", "Afternoon" , "Morning","Evening" , "Afternoon", "Afternoon" , "Morning","Evening","Afternoon","Morning" , "Evening", "Afternoon" , "Morning","Evening" , "Afternoon", "Afternoon" , "Morning","Evening","Afternoon","Morning" , "Evening", "Afternoon" , "Morning","Evening" , "Afternoon", "Afternoon" , "Morning","Evening","Afternoon","Morning" , "Evening", "Afternoon" , "Morning","Evening" , "Afternoon", "Afternoon" , "Morning"};
		
		

		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println("lessonID\t       Lesson \t\t    Price       day            \t        Date          \t       shift");
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");

		for (int count = 0; count < lesson_id.length; count++) {
                        if(Lesson[count].matches(i) || day[count].matches(i))
                        {
                         System.out.printf("%-20d     %-20s     %s    %-20s  %-20s   %-20s   \n", lesson_id[count], Lesson[count],price[count], day[count],workDate[count],time_shift[count]);

			//System.out.println( + "        \t" +  + "        \t" +  + "          \t" +  + "            \t" + + "        \t" +  + "        \t" + time_shift[count] + "        \t");
                        }
		}
	}

}
