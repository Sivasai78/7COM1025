
package WFC_lessons;

public class WFC_LessonReview {

	private int CustomerID;
	private String Customer_name;
	private String lessons;
	private int review;

	public int getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(int CustomerID) {
		this.CustomerID = CustomerID;
	}

	public String getCustomer_name() {
		return Customer_name;
	}

	public void setCustomer_name(String Customer_name) {
		this.Customer_name = Customer_name;
	}

	public String getlessons() {
		return lessons;
	}

	public void setlessons(String lessons) {
		this.lessons = lessons;
	}

	public int getreview() {
		return review;
	}

	public void setreview(int review) {
		this.review = review;
	}

	public WFC_LessonReview(int CustomerID, String Customer_name, String lessons, int review) {
		super();
		this.CustomerID = CustomerID;
		this.Customer_name = Customer_name;
		this.lessons = lessons;
		this.review = review;
	}

	@Override
	public String toString() {
		return "Lesson_review_data [CustomerID=" + CustomerID + ", Customer_name=" + Customer_name + ", lessons=" + lessons
				+ ", review=" + review + "]";
	}

}
