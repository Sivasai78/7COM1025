
package WFC_lessons;

import java.util.Scanner;


public class WFC_lessons {

  
    
    public static void Report_Montly(WFC_customer s[], int months,WFC_LessonReview[] R)
    {
        int Count_yoga_sunday = 0;
        int Count_yoga_saturday =0;
        int Count_zumba_saturday = 0;
        int Count_yoga_Sunday = 0;
        int count_review1 =5;
        int count_review2 =3;
        int count_review3 =2;
        int count_review4 =3;
        int count_review5 =3;
        
        for(int i =0;i<s.length;i++)
        {
            if(s[i] != null && s[i].getstatus().matches("Attended")) // Attended the lesson
            {
                String y = s[i].getName_Lesson();
                String d = s[i].getDay_week();
                int cust = s[i].getCustomerID();
                int review =0;
                for(int k = 0;k<R.length;k++)
                {
                    //System.out.println(R[k].getCustomerID());
                    if(R[k].getCustomerID() == cust)
                    {
                        review = R[k].getreview();
                        break;
                    }
                }
                if(y.matches("Yoga") && d.matches("Sunday"))
                {
                    
                    Count_yoga_sunday++;
                
                    
                }
                else if(y.matches("Yoga") && d.matches("Saturday"))
                {
                    Count_yoga_saturday++;
                      
                  
                }
                else if(y.matches("ZUMBA") && d.matches("Saturday"))
                {
                    Count_zumba_saturday++;
                     
                }
                else if(y.matches("ZUMBA") && d.matches("Sunday"))
                {
                    Count_yoga_Sunday++;
                    
                }
                
            }
            
            
        }
        
            
        
        System.out.println("Report of count of WFC_cust per lesson");
        System.out.println("Lesson \t\t Customer count \tReview");
        System.out.printf("YOGA - SUNDAY \t\t"   + "%-20s %s\n", Count_yoga_sunday, count_review1);
        System.out.printf("Zumba - SUNDAY \t\t"   + "%-20s %s\n", Count_yoga_Sunday, count_review2);
        System.out.printf("YOGA -SATURDAY \t\t"   + "%-20s %s\n", Count_yoga_saturday, count_review3);
        System.out.printf("ZUMBA-SATURDAY \t\t"   + "%-20s %s\n", Count_zumba_saturday, count_review5);




        
    }
    //Customers who have already registered 
    public int check_customer(WFC_customer s[], String Name_Lesson1 , int ID)
    {
        int count = 0;
         for (int i = 0; i < s.length; i++) {
                                  if(s[i] != null && s[i].getName_Lesson().matches(Name_Lesson1) && s[i].getCustomerID() == ID) 
                                  {
				
                                        
                                        System.out.println(s[i].getCustomerID() + "        \t" + s[i].getCustomerName() + "        \t" + s[i].getName_Lesson() + "          \t" +  s[i].getShift()+ " \t");
                                        System.out.println("Already Booked !!");
                                        return 0;    
					}
                                }
        return 1;
    }
    //Checking customer should not be more than 5 in each class lesson
    public int count_customers(WFC_customer s[],String Name_Lesson1,String Day_week1,String Set_time1)
    {
         int count = 0;
         //System.out.println("Customers who have registered ");
         for (int i = 0; i < s.length; i++) {
                                    if (s[i] != null && s[i].getName_Lesson().matches(Name_Lesson1) && s[i].getShift().matches(Set_time1) && s[i].getDay_week().matches(Day_week1)) {
					
                                        //System.out.println(s[i].getCustomerID() + "        \t" + s[i].getCustomerName() + "        \t" + s[i].getName_Lesson() + "          \t" +  s[i].getShift()+ " \t");
                                        count++;

					}
                                }
         if(count < 5)
         {
         return 1;
         }
         else
         {
             return 0;
         }
    }
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
                int CustomerID;
		String Customer_name;
		String Customer_status;
		String Name_Lesson;
		String Day_week;
		String Set_time;

                
                // intial count of the customer and review object array
		int Record_customer = 10;
                int Record_review = 20;
                
                //Count of the income for lessons
                int Record_income = 0;
                int Record_income2 = 0;
                int Record_income3 = 0;

		char Input_user = 'Y';

                WFC_lessons WFC = new WFC_lessons();
		WFC_customer WFC_cust[] = new WFC_customer[15];
		WFC_LessonReview Lesson_review_data[] = new WFC_LessonReview[30];
		WFC_timetable Weekend_48 = new WFC_timetable();
                WFC_cust[0] = new WFC_customer(1, "leon", "Attended", "Yoga","Sunday", "Evening");
                WFC_cust[1] = new WFC_customer(2, "tim", "Attended", "ZUMBA","Sunday", "Evening");
                WFC_cust[2] = new WFC_customer(3, "cook", "Attended", "Yoga","Sunday", "Evening");
                WFC_cust[3] = new WFC_customer(4, "tena", "Attended", "ZUMBA","Saturday", "Evening");
                WFC_cust[4] = new WFC_customer(5, "limm", "Booked", "ZUMBA","Sunday", "Morning");
                WFC_cust[5] = new WFC_customer(6, "porry", "Booked", "Yoga","Sunday", "Morning");
                WFC_cust[6] = new WFC_customer(7, "kina", "Attended", "Yoga","Sunday", "Evening");
                WFC_cust[7] = new WFC_customer(8, "tinu", "Booked", "Aquacise","Saturday", "Morning");
                WFC_cust[8] = new WFC_customer(9, "lomma", "Attended", "Yoga","Sunday", "Evening");
                WFC_cust[9] = new WFC_customer(10, "chaeery", "Booked", "Yoga","Sunday", "Evening");
                
                
                //Review of 20 WFC_cust 
                
               Lesson_review_data[0] = new WFC_LessonReview(1,"Good class","Yoga",2);
               Lesson_review_data[1] = new WFC_LessonReview(2,"not good class","ZUMBA",3);
               Lesson_review_data[2] = new WFC_LessonReview(3,"fair class ","ZUMBA",3);
               Lesson_review_data[3] = new WFC_LessonReview(4,"fair class","Yoga ",2);
               Lesson_review_data[4] = new WFC_LessonReview(5,"fair class","Yoga",4);
               Lesson_review_data[5] = new WFC_LessonReview(6,"class was good","ZUMBA",5);
               Lesson_review_data[6] = new WFC_LessonReview(7,"fair class","Yoga",1);
               Lesson_review_data[7] = new WFC_LessonReview(8,"Good class","Aquacise",2);
               Lesson_review_data[8] = new WFC_LessonReview(9,"Interesting class ","ZUMBA",4);
               Lesson_review_data[9] = new WFC_LessonReview(10,"not Good class","Aquacise",5);
               Lesson_review_data[10] = new WFC_LessonReview(11," notGood class","ZUMBA",2);
               Lesson_review_data[11] = new WFC_LessonReview(12,"class was good ","Yoga",3);
               Lesson_review_data[12] = new WFC_LessonReview(13,"Boring class ","ZUMBA",4);
               Lesson_review_data[13] = new WFC_LessonReview(14,"bad expereicne","Aquacise",5);
               Lesson_review_data[14] = new WFC_LessonReview(15,"Good class ","ZUMBA",1);
               Lesson_review_data[15] = new WFC_LessonReview(16,"Good class","Yoga",3);
               Lesson_review_data[16] = new WFC_LessonReview(17,"class was good","Aquacise",3);
               Lesson_review_data[17] = new WFC_LessonReview(18,"good expereicne","Aquacise",4);
               Lesson_review_data[18] = new WFC_LessonReview(19,"class was good","Yoga",4);
               Lesson_review_data[19] = new WFC_LessonReview(20,"not good class","Aquacise",5);
               Lesson_review_data[20] = new WFC_LessonReview(21,"low class","Yog",3);
               
               
               
               
               
               
               

         
                
		while (Input_user == 'Y') {
			Scanner sc = new Scanner(System.in);
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("           Welcome to Weekend Fitness Club (WFC)");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("\t1: Show timetable");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("\t2: Class Lesson - Booking ");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("\t3: Class Lesson - Review");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("\t4: Class Lesson -  Update");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("\t5: Highest generated Income");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("\t6: Report Lessons attended by customer ");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("\t7: View Report of Booked Lesson by Customer");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("\t8: Exit Application");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("\tENTER YOUR CHOICE");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

			int INPUT = sc.nextInt();

			switch (INPUT) {
			
			case 1:
				
                                System.out.println("Enter your Choice");
                                System.out.println("1. For DAY // 2. For Fitness Class - Yoga , Zumba , Aquacise");
                                String input = sc.next(); 
                                
                                System.out.println("~~~~~~~48 Lessons Time Table~~~~~~~~~");
                                //Method to display timetable
				Weekend_48.displayTimeTable(input);
				break;
			
			case 2:
                                
				System.out.println("*****BOOK A LESSON*****");
				System.out.println("Customer ID: ");
				CustomerID = sc.nextInt();
				System.out.println("Customer Name: ");
				Customer_name = sc.next();
				
				Customer_status = "Booked";

				System.out.println("Lesson Name - Yoga , spin , Aquacise: ");
				Name_Lesson = sc.next();
				System.out.println("Week Day - Sunday or Saturday: ");
				Day_week = sc.next();
				System.out.println("Shift: - Morning , Evening");
				Set_time = sc.next();
                                //checeking if already booked
                                int count2 = WFC.check_customer(WFC_cust, Name_Lesson, CustomerID);
                               
                                
                                if(count2==1)
                                {
                                    //checking if not booked
                                    int count1 = WFC.count_customers(WFC_cust,Name_Lesson,Day_week,Set_time);
                                    if(count1 == 1)
                                    {
                                        
                                    WFC_cust[Record_customer] = new WFC_customer(CustomerID, Customer_name, Customer_status, Name_Lesson,Day_week, Set_time);
                                    Record_customer++;
                                    System.out.println("Booked Lesson");
                                    }
                                    else{
                                        System.out.println("Lesson is full");
                                    }
                                }
                                else
                                {
                                    System.out.println("Already Booked the lesson !!");
                                }
				break;
                                
			case 3:
				System.out.println("~~~~~Write a review~~~~~~");
				System.out.println("Customer ID: ");
                               CustomerID = sc.nextInt();
                                System.out.println("Write Review");
				 String r = sc.next();
                                 String p = sc.next();
                                System.out.println("Give rating 1-5");
				int rating = sc.nextInt();
				
				System.out.println("Lesson Name");
				Name_Lesson = sc.next();
                               
				
                               

				Lesson_review_data[Record_review] = new WFC_LessonReview(CustomerID, r, Name_Lesson, rating);
				Record_review++;
				System.out.println("Review Booked Successfully..!!");
				break;

			case 4:
				System.out.println("~~~~UPDATE~~~~~~~~~");
				System.out.println("ENTER - Customer ID: OR Booking ID ");
				CustomerID = sc.nextInt();
				 for (int i = 0; i < WFC_cust.length; i++) {
                                        if(WFC_cust[i].getCustomerID() == CustomerID && WFC_cust[i] != null)
                                        {
                                           
                                                String name = WFC_cust[i].getName_Lesson();
                                                String day = WFC_cust[i].getDay_week();
                                                
                                                System.out.println("Shift Status: - > Cancel , Morning , Evening");
						Set_time = sc.next();
                                                    //Checking if lesson is booked or not
                                                int count3 = WFC.count_customers(WFC_cust,name,day,Set_time);
                                                if(count3==1)
                                                {
                                                   System.out.println("Status Shifted to"+Set_time);
                                                   WFC_cust[i].setshift(Set_time);
                                                   break;

                                                }
                                                else{
                                                     
                                                     System.out.println("Lesson is full !!");
                                                     break;
                                                    }
                                                
                                               
                                        }
                                        
                                 }
                              
				
				break;

			case 5:
				System.out.println("*****HIGHEST INCOME*****");
                                System.out.println("Income of Yoga - $400 , Zumba - $300");
                                System.out.println("Income of Aquacise - $600 , Spin - $700");

				for (int i = 0; i < Record_customer; i++) {
                                       
					if (WFC_cust[i].getName_Lesson().matches("Yoga")) {

				           Record_income = 400 + Record_income;

					}
                                        else if(WFC_cust[i].getName_Lesson().matches("ZUMBA"))
                                        {
                                            Record_income2 = 300 + Record_income2;
                                        }
                                        else if(WFC_cust[i].getName_Lesson().matches("Aquacise"))
                                        {
                                            Record_income3 = 600 + Record_income3;
                                        }
                                        else if(WFC_cust[i].getName_Lesson().matches("Spin"))
                                        {
                                            int Record_income4 = 900 + Record_income3;
                                        }
                                        else {
						System.out.println("");
					}
				}
                                
                                if(Record_income > Record_income2 && Record_income > Record_income3)
                                {
                                    System.out.print("Highest income Genreated by YOGA : - ");
                                    System.out.println(Record_income);
                                }
                                else if(Record_income2 > Record_income && Record_income2 > Record_income3)
                                {
                                    System.out.print("Highest income Genreated by ZUMBA");
                                    System.out.println(Record_income2);
                                }
                                else if(Record_income3 > Record_income && Record_income3 > Record_income2)
                                {
                                    System.out.print("Highest income Genreated by Aquacise - ");
                                    System.out.println(Record_income3);
                                }
                                else{
                                    System.out.println("");
                                }
				break;

                        case 6:
                                System.out.println("Monthly Lesson Report");
                                System.out.println("Enter the month:-");
                                int month = sc.nextInt();
                                Report_Montly(WFC_cust,month,Lesson_review_data);
                         
                                break;
                                
                         case 7:
				System.out.println("SEE ALL Report of Booked lessons:-");
                                System.out.println("********************************************************************************************************************************************");
                                System.out.println("Customer ID\t  Name \t     Lesson \t    Shift ");
                                System.out.println("********************************************************************************************************************************************");

                                   for (int i = 0; i < Record_customer; i++) {
                                    if (WFC_cust[i] != null) {
					
                                            
                                        System.out.println(WFC_cust[i].getCustomerID() + "        \t" + WFC_cust[i].getCustomerName() + "        \t" + WFC_cust[i].getName_Lesson() + "          \t" +  WFC_cust[i].getShift()+ " \t");


					}
                                }
                                
				break;
      
                        case 8:
				System.out.println("Existed Successfully");
				break;

			default:
				System.out.println("ERROR");
				System.out.println("Enter proper command");
				break;

			}
			System.out.println("Do you like to continue...!!");
			Input_user = sc.next().charAt(0);
			if (Character.isLowerCase(Input_user)) {
				Input_user = Character.toUpperCase(Input_user);
			}

		}
	}
    
}
