/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WFC_lessons;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class WFC_lessonsIT {
    
    public WFC_lessonsIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    
     

    /**
     * Test of Report_Montly method, of class WFC_lessons.
     */
   
    /**
     * Test of check_customer method, of class WFC_lessons.
     */
    @Test
    public void testCheck_customer() {
        System.out.println("check_customer");
         WFC_customer[] s = new WFC_customer[10];
        s[0] = new WFC_customer(1, "leon", "Attended", "Yoga","Sunday", "Evening");
        s[1] = new WFC_customer(2, "tim", "Attended", "ZUMBA","Sunday", "Evening");
         s[2] = new WFC_customer(3, "cook", "Attended", "Yoga","Sunday", "Evening");
                s[3] = new WFC_customer(4, "tena", "Attended", "ZUMBA","Saturday", "Evening");
                s[4] = new WFC_customer(5, "limm", "Booked", "ZUMBA","Sunday", "Morning");
                s[5] = new WFC_customer(6, "porry", "Booked", "Yoga","Sunday", "Morning");
                s[6] = new WFC_customer(7, "kina", "Attended", "Yoga","Sunday", "Evening");
                s[7] = new WFC_customer(8, "tinu", "Booked", "Aquacise","Saturday", "Morning");
                s[8] = new WFC_customer(9, "lomma", "Attended", "Yoga","Sunday", "Evening");
                s[9] = new WFC_customer(10, "chaeery", "Booked", "Yoga","Sunday", "Evening");
        String Name_Lesson1 = "Yoga";
        int ID = 1;
        WFC_lessons instance = new WFC_lessons();
        int expResult = 0;
        int result = instance.check_customer(s, Name_Lesson1, ID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of count_customers method, of class WFC_lessons.
     */
    @Test
    public void testCount_customers() {
        System.out.println("count_customers");
         WFC_customer[] s = new WFC_customer[10];
        s[0] = new WFC_customer(1, "leon", "Attended", "Yoga","Sunday", "Evening");
        s[1] = new WFC_customer(2, "tim", "Attended", "ZUMBA","Sunday", "Evening");
         s[2] = new WFC_customer(3, "cook", "Attended", "Yoga","Sunday", "Evening");
                s[3] = new WFC_customer(4, "tena", "Attended", "ZUMBA","Saturday", "Evening");
                s[4] = new WFC_customer(5, "limm", "Booked", "ZUMBA","Sunday", "Morning");
                s[5] = new WFC_customer(6, "porry", "Booked", "Yoga","Sunday", "Morning");
                s[6] = new WFC_customer(7, "kina", "Attended", "Yoga","Sunday", "Evening");
                s[7] = new WFC_customer(8, "tinu", "Booked", "Aquacise","Saturday", "Morning");
                s[8] = new WFC_customer(9, "lomma", "Attended", "Yoga","Sunday", "Evening");
                s[9] = new WFC_customer(10, "chaeery", "Booked", "Yoga","Sunday", "Evening");
        String Name_Lesson1 = "Yoga";
        String Day_week1 = "Sunday";
        String Set_time1 = "Evening";
        WFC_lessons instance = new WFC_lessons();
        int expResult = 0;
        int result = instance.count_customers(s, Name_Lesson1, Day_week1, Set_time1);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of main method, of class WFC_lessons.
     */
    @Test
    public void testMain() {
        System.out.println("main");
      
        //WFC_lessons.main(args);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}
