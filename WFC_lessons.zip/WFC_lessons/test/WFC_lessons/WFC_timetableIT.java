/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WFC_lessons;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class WFC_timetableIT {
    
    public WFC_timetableIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of displayTimeTable method, of class WFC_timetable.
     */
    @Test
    public void testDisplayTimeTable() {
        System.out.println("displayTimeTable");
        String i = "Yoga";
        WFC_timetable instance = new WFC_timetable();
        instance.displayTimeTable(i);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}
